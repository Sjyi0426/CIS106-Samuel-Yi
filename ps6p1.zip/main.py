#inputs
pamount = float(input("Enter Principle: "))
intrate = float(input("Enter interest rate: "))
totint = 0

#header
print(format("Year", '6s'), format("Beginning", '13s'), format("Ending",'10s'))
print(format("",'7s'), format("Balance", '12s'), format("Balance", '12s'))

#Loop
for count in range (1,6):
  annint = pamount * intrate
  endbal = pamount + annint
  print(format(count,'2d'), format(pamount,'13,.2f'),format(endbal,'12,.2f'))
  pamount = endbal
  totint = totint + annint

#final output
print("Total interest earned: $", format(totint,',.2f'))