def compavgscore(exam1,exam2,exam3):
  total = exam1 + exam2 + exam3
  avgscore = total / 3

  return total,avgscore

lastname = input("Enter last name: ")
exam1 = float(input("Enter exam 1 score: "))
exam2 = float(input("Enter exam 2 score: "))
exam3 = float(input("Enter exam 3 score: "))

total, avgscore = compavgscore(exam1,exam2,exam3)

print(lastname)
print("Total points: ", total)
print("Average exam score: ", format(avgscore,',.2f'))