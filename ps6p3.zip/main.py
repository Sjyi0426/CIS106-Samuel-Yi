#conenct to txt file
f = open("data1.txt", "r")
tbonus = 0
lastname = f.readline().rstrip('\n')

while lastname != "":
  salary = float(f.readline())
  if salary >= 100000:
    brate = .2
  elif salary == 50000:
    brate = .15
  else:
    brate = .1
  bonus = salary * brate
  print(lastname)
  print("Salary: $", format(salary,',.2f'))
  print("Bonus:  $", format(bonus,',.2f'))
  print("")
  tbonus = tbonus + bonus
  lastname = f.readline().rstrip('\n')

print("Total Bonus: $",format(tbonus,',.2f'))