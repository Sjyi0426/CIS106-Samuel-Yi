#input
lastname = input("Enter last name: ")
salary = float(input("Enter salary: "))
joblvl = int(input("Enter job level: "))

#process
if joblvl >= 10:
  brate = 0.25
elif 5 <= joblvl and joblvl <= 9:
  brate = 0.20
else:
  brate = 0.10

bonus = salary * brate

#output
print("Last name: ", lastname)
print("Bonus: $", bonus)