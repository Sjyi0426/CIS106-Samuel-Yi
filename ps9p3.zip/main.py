def compcommission(sales):
  if sales > 100000:
    commission = sales * 0.10
  else:
    commission = sales * 0.05

  target = sales * 1.05

  return commission,target

lastname = input("Enter last name: ")
sales = float(input("Enter sales: "))

commission, target = compcommission(sales)

print(lastname)
print("Commission: $", format(commission,',.2f'))
print("Next year's sales target: $", format(target,',.2f'))