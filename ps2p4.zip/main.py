#comment input
n = input("Enter last name: ")
c = int(input("Enter credits taken: "))

#process phase
t = (c * 250) + 100

#output
print(n)
print("Tuition: $", t)
