def compbatavg(nohits,nobats):
  batavg = float(nohits) / float(nobats)

  return batavg

lastname = input("Enter last name: ")
nohits = float(input("Enter number of hits: "))
nobats = float(input("Enter number of bats: "))

batavg = compbatavg(nohits,nobats)

print(lastname)
print("Batting Average: ",format(batavg,'.2f'))