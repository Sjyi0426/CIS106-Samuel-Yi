#input
name = input("Enter name of appliance: ")
apcost = float(input("Enter cost of appliance: "))

#process
if apcost > 1000:
  wcost = 0.1 * apcost
else:
  wcost = 0.05 * apcost

total = apcost + wcost

#output
print("Appliance Name: ", name)
print("Cost of appliance: $", apcost)
print("Cost of warranty: $", wcost)
print("Total: $", total)