response = input("Do you want to start the program? (Yes or No): ")

def compforecast(month,sales):
    if month == "Jan" or month == "Feb" or month == "Mar":
      percent = 0.10
    elif month == "Apr" or month == "May" or month == "Jun":
      percent = 0.15
    elif month == "Jul" or month == "Aug" or month == "Sep":
      percent = 0.20
    else:
      percent = 0.25

    forecast = float(sales) * (1 + percent)

    return forecast

while response == "Yes":
  
  lastname = input("Enter last name: ")
  month = input("Enter month: ")
  sales = float(input("Enter sales: "))

  forecast = compforecast(month,sales)

  print("Next month sales:", format(forecast,',.2f'))

  response = input("Do you want to start the program again? (Yes or No): ")