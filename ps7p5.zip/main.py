def comptuition(credit,dcode):
  if dcode == "I":
    tuition = float(credit) * 250.00
  else:
    tuition = float(credit) * 550.00

  return tuition

lastname = input("Enter last name: ")
credit = float(input("Enter credit hours: "))
dcode = input("Enter district code (I or O): ")

tuition = comptuition(credit, dcode)

print(lastname)
print("Tuition owed: $", format(tuition,',.2f'))