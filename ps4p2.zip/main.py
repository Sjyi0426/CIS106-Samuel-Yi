#input
partno = int(input("Enter part number: "))
qty = input("Enter quantity: ")

#process
if partno == 10 or partno == 55:
  unitprice = 1.00
elif partno == 99:
  unitprice = 2.00
elif partno == 80 or partno == 70:
  unitprice = 3.00
else:
  unitprice = 5.00

total = float(qty) * unitprice

#output
print("Part Number: ", partno)
print("Cost per unit: $", unitprice)
print("Total cost: $", total)