response = input("Do you want to start the program? (Yes or No): ")
totMSRP = 0
totsales = 0


def compdoorprice(MSRP,make,model,vcode):
  if make == "Honda" and model == "Accord":
    percentoff = 0.10
  elif make == "Toyota" and model == "Rav4":
    percentoff = 0.15
  elif vcode == "Y":
    percentoff = 0.30
  else:
    percentoff = 0.05

  discount = MSRP * percentoff
  tax = (MSRP - discount) * 0.07
  doorprice = MSRP - discount + tax

  return doorprice

while response == "Yes":
  make = input("Enter the make of the car: ")
  model = input("Enter the model of the car: ")
  vcode = input("Enter the electric vehicle code (Y or N): ")
  MSRP = float(input("Enter MSRP: "))

  doorprice = compdoorprice(MSRP,make,model,vcode)

  print("Total: $", doorprice)

  totMSPR = totMSRP + MSRP
  totsales = totsales + doorprice
  
  response = input("Do you want to start the program again? (Yes or No): ")

print("Sum of all MSPR:  $", format(totMSRP,',.2f'))
print("Sum of all sales: $", format(totsales,',.2f'))