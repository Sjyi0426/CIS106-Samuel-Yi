#input
startv = int(input("Enter start value: "))
stopv = int(input("Enter stop value: "))
incrv = int(input("Enter increment value: "))

#process / output
while startv <= stopv:
  print(startv)
  startv = startv + incrv