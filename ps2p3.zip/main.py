#comment input
l = float(input("Enter length: "))
w = float(input("Enter width: "))

#process phase
a = l * w
c = (2 * l) + (2 * w)

#output
print("Area = ", a)
print("Circumference = ", c)