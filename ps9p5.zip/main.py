total = 0
tax = 0

def comptotal(qty,price):
  global total
  total = qty * price
  global tax
  tax = total * 0.07

qty = float(input("Enter quantity: "))
price = float(input("Enter unit price: "))

comptotal(qty,price)

print("Total: $", format(total,',.2f'))
print("Tax:   $", format(tax,',.2f'))