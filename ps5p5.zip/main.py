#input
dtotal = 0
response = input("Do you want to compute the discount? (Yes or No): ")

#process
while response == "Yes":
  qty = float(input("Enter quantity: "))
  price = float(input("Enter price of item: "))
  extprice = qty * price
  if extprice > 10000.00:
    discount = 0.25
  else:
    discount = 0.10
  damount = extprice * discount
  total = extprice - damount
  dtotal = dtotal + damount

  print("Extended Price: $", extprice)
  print("Discount Amount: $", damount)
  print("Total: $", total)

  response = input("Do you want to compute the discount? (Yes or No): ")
#output
print("Sum of all the discounts: $", dtotal)