#inputs
n1 =1
n2 = 1
n3 = 0

#process / output
for count in range (20):
  print(format(n1,',d'))
  n3 = n1 + n2
  n1 = n2
  n2 = n3