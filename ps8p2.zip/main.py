response = input("Do you want to start the program? (Yes or No): ")

def compsqrfootage(length,width,height):
  sqrfootage = (2 * length * width) + (2 * length * height) + (2 * width * height)

  return sqrfootage

while response == "Yes":
  length = float(input("Enter length: "))
  width = float(input("Enter width: "))
  height = float(input("Enter  height: "))

  sqrfootage = compsqrfootage(length,width,height)

  gallons = sqrfootage / 50

  print("Number of gallons needed:", format(gallons,',.2f'))

  response = input("Do you want to start the program again? (Yes or No): ")