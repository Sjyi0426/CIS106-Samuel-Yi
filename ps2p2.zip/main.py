#comment input
n = (input("Enter last name: "))
h = int(input("Enter hours: "))
p = float(input("Enter pay rate: "))

#process phase
g = (h * p)

#output
print(n)
print("Gross pay: ", g)