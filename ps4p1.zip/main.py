#input
qty = float(input("Enter the quantity of widgets: "))

#process
if qty > 10000:
  price = 10
elif 5000 <= qty and qty <= 10000:
  price = 20
else:
  price = 30

extprice = qty * price
tax = extprice * 0.07
total = extprice + tax

#output
print("Extended Price: $", extprice)
print("Tax: $", tax)
print("Total: $", total)