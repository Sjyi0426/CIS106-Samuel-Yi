#conenct to txt file
f = open("data2.txt", "r")
count = 0
total = 0
item = str(f.readline().rstrip('\n'))

while item != "":
  count = count + 1
  qty = float(f.readline())
  price = float(f.readline())
  
  extprice = qty * price
  total = total + extprice
  
  print("Item:            ", item)
  print("Quantity:        ", qty)
  print("Price:          $", price)
  print("Extended Price: $", extprice)
  print("")
  item = f.readline().rstrip('\n')

avg = total / count
print("Total extended price: $", format(total,',.2f'))
print("Number of Orders:      ", format(count,',d'))
print("Average Order:        $", format(avg,',.2f'))