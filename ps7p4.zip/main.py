def comppayrate(jobcode):
  if jobcode == "L":
    payrate = 25.00
  elif jobcode == "A":
    payrate = 30.00
  else:
    payrate = 50.00
  
  return payrate

def compgrosspay(payrate,hours):
  if hours > 40:
    grosspay = (payrate*40)+((float(hours) - 40)*(payrate* 1.5))
  else:
    grosspay = payrate * hours

  return grosspay

lastname = input("Enter last name: ")
jobcode = input("Enter job code (L,A,J): ")
hours = float(input("Enter hours worked: "))

payrate = comppayrate(jobcode)
grosspay = compgrosspay(payrate, hours)

print(lastname)
print("Gross pay: $", format(grosspay,',.2f'))