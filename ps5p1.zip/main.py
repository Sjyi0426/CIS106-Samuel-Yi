#input
startv = 1
stopv = 25
incrv = 2

while startv <= stopv:
  print(startv)
  startv = startv + incrv
