def compdiscount(qty,price,drate):
  damount = (qty * price) * drate
  dprice = (qty* price) - damount

  return dprice,damount

qty = float(input("Enter quantity: "))
price = float(input("Enter unit price: "))
drate = float(input("Enter discount rate: "))

dprice, damount = compdiscount(qty,price,drate)

print("Discount Price:  $", format(dprice,',.2f'))
print("Discount Amount: $", format(damount,',.2f'))
print("Quantity: ", qty)
print("Unit Price: ", format(price,',.2f'))