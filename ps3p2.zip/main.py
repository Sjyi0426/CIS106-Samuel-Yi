#input
item = input("Enter one of the items (A or B): ")
qty = float(input("Enter a quantity: "))

#process
if item == "A":
  up = 10.00
else:
  up = 20.00

extprice = qty * up

#output
print("Item Selected: ", item)
print("Unit Price: $", up)
print("Extended Price: $", extprice)