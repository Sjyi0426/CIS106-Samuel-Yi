#input
qty = float(input("Enter a quantity: "))

#process
if qty >= 1000:
  up = 3.00
else:
  up = 5.00

extprice = qty * up
tax = extprice * 0.07
total = extprice + tax

#output
print("Quantity: ", qty)
print("Unit Price: $", up)
print("Extended Price: $", extprice)
print("Tax: $", tax)
print("Total: $", total)