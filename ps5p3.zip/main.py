#inputs
count = 0

response = input("Do you want to compute your average score? (Yes or No): ")

while response == "Yes":
  count = count + 1
  lastname = input("Enter last name: ")
  score1 = float(input("Enter exam score 1: "))
  score2 = float(input("Enter exam score 2: "))
  avg = (score1 + score2) / 2
  print("Last Name: ", lastname)
  print("Average Exam Score: ", avg)
  response = input("Do you want to compute your average score? (Yes or No): ")
print("Total Number of Students: ", count)