#conenct to txt file
f = open("data3.txt", "r")
nostudent = 0
total = 0
lastname = f.readline().rstrip('\n')

while lastname != "":
  nostudent = nostudent + 1
  dc = f.readline()
  if dc == "I":
    cost = 250
  else:
    cost = 500
  credit = float(f.readline())
  tuition = cost * credit
  total = total + tuition
  print(lastname)
  print("Credits Taken: $", credit)
  print("Tuition Owed:  $", format(tuition,',.2f'))
  print("")
  lastname = f.readline().rstrip('\n')

print("Total Tuition: $", format(total,',.2f'))
print("Number of Students: ", nostudent)