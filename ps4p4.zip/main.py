#input
qty = int(input("Enter number of concert tickets: "))

#process
if qty >= 25:
  ticprice = 50
elif 10 <= qty and qty <= 24:
  ticprice = 60
elif 5 <= qty and qty <= 9:
  ticprice = 70
else:
  ticprice = 75

total = qty * ticprice

#output
print("Number of tickets: ", qty)
print("Price per ticket: $", ticprice)
print("Total cost: $", total)