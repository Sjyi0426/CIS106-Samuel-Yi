response = input("Do you want to start the program? (Yes or No): ")
ticketsum = 0

def compticketprice (milesdt):
  if milesdt >= 30:
    ticketprice = 12.00
  elif milesdt >= 20 and milesdt <= 29:
    ticketprice = 10.00
  elif milesdt >= 10 and milesdt <= 19:
    ticketprice = 8.00
  else:
    ticketprice = 5.00

  return ticketprice

while response == "Yes":
  lastname = input("Enter last name: ")
  milesdt = float(input("Enter miles from downtown Chicago: "))

  ticketprice = compticketprice(milesdt)

  print("Ticket price: $", format(ticketprice,'.2f'))

  ticketsum = ticketsum + ticketprice

  response = input("Do you want to start the program again? (Yes or No): ")

print("Sum price of all tickets: $", format(ticketsum,',.2f'))