def compmpg(miles,gallons):
  mpg = float(miles) * float(gallons)

  return mpg

def compgcost(gallons):
  gcost = float(gallons) * 2.50

  return gcost

city = input("Enter the destination city: ")
miles = float(input("Enter miles traveled: "))
gallons = float(input("Enter gallons used: "))

mpg = compmpg(miles,gallons)
gcost = compgcost(gallons)

print("Destination City: ", city)
print("Miles per gallon: ", mpg)
print("Cost of gas:     $", format(gcost,',.2f'))