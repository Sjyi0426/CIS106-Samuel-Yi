#comment input
q = float(input("Enter a quantity: "))
p = float(input("Enter a price: "))

#process phase
e = q + p

#output
print("The extended price is ", e)