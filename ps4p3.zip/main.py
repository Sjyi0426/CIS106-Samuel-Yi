#input
pamount = int(input("Enter the principal amount of a CD: "))
year = int(input("Enter years to maturity of CD: "))

#process
if pamount > 100000 and year == 5:
  intrate = 0.06
elif 50000 <= pamount and pamount <= 100000 and year == 10:
  intrate = 0.05
elif 50000 <= pamount and pamount <= 100000 and year == 5:
  intrate = 0.04
else:
  intrate = 0.02

intamount = pamount * intrate

#output
print("Principle Amount: $", pamount)
print("Interest Rate: ", intrate, "%")
print("Interest Amount: $", intamount)