#input
count = 0
totalgross = 0
response = input("Do you want to compute your gross pay? (Yes or No): ")

#process
while response == "Yes":
  count = count + 1
  lastname = input("Enter last name: ")
  hours = int(input("Enter hours worked: "))
  payrate = float(input("Enter rate of pay: "))
  grosspay = hours * payrate
  totalgross = totalgross + grosspay
  if hours > 40:
    print("Employee Time: ", hours)

  print("Last Name: ", lastname)
  print("Gross Pay: $", grosspay)

  response = input("Do you want to compute your gross pay? (Yes or No): ")

#output
avggross = totalgross / count
print("Total Gross Pay: $", totalgross)
print("Total Number of Employees: ", count)
print("Average Gross Pay: $", avggross)