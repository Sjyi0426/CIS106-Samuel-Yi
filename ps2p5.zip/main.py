#comment input
p = float(input("Enter price: $"))
d = float(input("Enter discount: "))

#process phase
da = p * d
dp = p - da

#output
print("Discount Amount: $", da)
print("Discounted Price: $", dp)