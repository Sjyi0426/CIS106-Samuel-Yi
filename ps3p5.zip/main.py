#input
lastname = input("Enter last name: ")
nodep = float(input("Enter number of dependents: "))
grosspay = float(input("Enter gross income: "))

#process
adjgross = grosspay - (12000.00 * nodep)
if adjgross > 50000:
  tax = adjgross * 0.2
else:
  tax = adjgross * 0.1

if tax < 0:
  tax = 100

#output
print(lastname)
print("Gross Income: $", grosspay)
print("Number of dependents: ", nodep)
print("Adjust Gross Income: $", adjgross)
print("Income Tax: $", tax)