#input
nobook = float(input("Enter the number of books to order: "))
cpb = float(input("Enter cost per book: "))

#process
total = nobook * cpb

if total > 50:
  shipping = 0
else:
  shipping = 25.00

#output
print("Order Total: $", total)
print("Shipping Cost: $ ", shipping)