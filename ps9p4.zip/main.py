def compavgscore(game1,game2,game3,handicap):
  avgscore = (game1 + game2 + game3) / 3
  handscore = avgscore + handicap

  return avgscore,handscore

lastname = input("Enter last name: ")
game1 = float(input("Enter game 1 score: "))
game2 = float(input("Enter game 2 score: "))
game3 = float(input("Enter game 3 score: "))
handicap = float(input("Enter Handicap: "))

avgscore, handscore = compavgscore(game1,game2,game3,handicap)

print(lastname)
print("Average score: ", format(avgscore,',.2f'))
print("Average score with handicap: ", format(handscore,',.2f'))