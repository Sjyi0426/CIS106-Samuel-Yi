response = input("Do you want to start the program? (Yes or No): ")
marketsum = 0
valuesum = 0

def compvalue (county,market):
  if county == "Cook":
    valuepercent = 0.90
  elif county == "DuPage":
    valuepercent = 0.80
  elif county == "McHenry":
    valuepercent = 0.75
  elif county == "Kane":
    valuepercent = 0.60
  else:
    valuepercent = 0.70

  value = market * valuepercent

  return value


while response == "Yes":
  county = input("Enter county: ")
  market = float(input("Enter market value of home: "))

  value = compvalue(county,market)
  
  print("Assessed Value: $", format(value,',.2f'))

  marketsum = marketsum + market
  valuesum = valuesum + value

  response = input("Do you want to start the program again? (Yes or No): ")

print("Sum of all market values:   $",format(marketsum,',.2f'))
print("SUm of all assessed values: $", format(valuesum,',.2f'))